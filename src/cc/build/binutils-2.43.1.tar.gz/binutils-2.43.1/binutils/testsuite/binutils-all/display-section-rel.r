.*: Warning: Section '.*' was not dumped because it does not exist

Relocation section '.*' at offset 0x.* contains .* entries:
#...
